#pragma once

#include "Czas.h"
#include "Kwadrat.h"

float Kwadrat1 ();
