#include "Iloczyn2.h"
#include "Przyspieszenie.h"
#include "Kwadrat1.h"

float Iloczyn2 ()
{
  return Przyspieszenie()*Kwadrat1();
}

