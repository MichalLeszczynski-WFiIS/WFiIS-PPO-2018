#pragma once

inline float Czas ()
{
  return 1.4;
}
