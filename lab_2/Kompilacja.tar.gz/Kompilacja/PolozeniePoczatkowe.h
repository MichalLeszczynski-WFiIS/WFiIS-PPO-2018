#pragma once

float PolozeniePoczatkowe ();

