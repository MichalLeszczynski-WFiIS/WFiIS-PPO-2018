//#pragma once

float Iloczyn (const float czynnikA, const float czynnikB);