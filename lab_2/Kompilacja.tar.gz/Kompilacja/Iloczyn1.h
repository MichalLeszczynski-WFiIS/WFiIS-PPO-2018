#pragma once

float Iloczyn1 ();
