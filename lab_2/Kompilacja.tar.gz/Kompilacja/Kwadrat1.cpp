#include "Kwadrat1.h"

float Kwadrat1 ()
{
  return Kwadrat (Czas());
}
