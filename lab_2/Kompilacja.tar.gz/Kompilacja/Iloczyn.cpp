#include"Iloczyn.h"

float Iloczyn (const float czynnikA, const float czynnikB)
{
  return czynnikA*czynnikB;
}