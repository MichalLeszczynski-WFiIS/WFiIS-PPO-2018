#include"Przyspieszenie.h"

float Przyspieszenie ()
{
  return 42.42;
}
