#pragma once

#include "Suma.h"
#include "Iloczyn1.h"
#include "Iloczyn2.h"

float Suma1 ();
