#pragma once

float Iloczyn2 ();
