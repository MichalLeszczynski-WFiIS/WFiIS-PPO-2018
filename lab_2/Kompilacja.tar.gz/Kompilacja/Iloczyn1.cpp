#include "Iloczyn1.h"
#include "Iloczyn.h"
#include "Czas.h"
#include "Predkosc.h"

float Iloczyn1 ()
{
  return Iloczyn(Czas(), Predkosc());
}