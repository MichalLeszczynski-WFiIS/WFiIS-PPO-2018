#pragma once

inline float Suma (const float skladnikA, const float skladnikB)
{
  return skladnikA + skladnikB;
}
