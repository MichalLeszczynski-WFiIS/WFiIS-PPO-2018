#pragma once

inline float Predkosc ()
{
  return 333;
}
