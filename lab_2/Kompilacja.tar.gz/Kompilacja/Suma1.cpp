#include "Suma1.h"

float Suma1 ()
{
  return Suma (Iloczyn1(), Iloczyn2());
}
