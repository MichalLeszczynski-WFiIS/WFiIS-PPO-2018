#pragma once

float Przyspieszenie ();
