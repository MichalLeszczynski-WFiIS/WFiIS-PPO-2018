#pragma once

inline float Kwadrat (const float czynnik)
{
    return czynnik*czynnik;
}
