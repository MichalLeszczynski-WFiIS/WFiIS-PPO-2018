float PolozeniePoczatkowe ()
{
  return 44;
}
